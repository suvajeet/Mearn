var gulp = require('gulp');
concat=require('gulp-concat'),
imagemin=require('gulp-imagemin'),
jshint=require('gulp-jshint'),
notify=require('gulp-notify'),
plumber=require('gulp-plumber'),//handle error
uglify=require('gulp-uglify'),
stripDebug=require('gulp-strip-debug'),
liveReload=require('gulp-livereload');

onError = function(err)
{
console.log(err);
}

gulp.task('default',['copyfiles','images','jshint','scripts','watch']);
gulp.task('copyfiles',function()
{
gulp.src('./src/*/.{txt,doc}')
.pipe(gulp.dest('./dest'));
});

gulp.task('images',function()
{
gulp.src('./src/myfiles/*')
.pipe(plumber({errorHandler : onError}))
.pipe(imagemin())
.pipe(gulp.dest('./dest'))
.pipe(notify({message :'Your Image has been copied'}));
});

gulp.task('jshint',function()
{
gulp.src('./javascript/*.js')
.pipe(plumber({errorHandler : onError}))
.pipe(jshint())
.pipe(jshint.reporter('default'))
.pipe(notify({message:'File error check is completed'}));
});

gulp.task('scripts',function()
{return gulp.src('./src/scripts/*.js')
.pipe(plumber({errorHandle:onError}))
.pipe(concat('app.min.js'))
.pipe(stripDebug())
.pipe(uglify())
.pipe(gulp.dest('./js/'))
.pipe(notify({message:'Script task complete'}));
});

//This will handle watching and liveReload server to refresh things

gulp.task('watch',function()
{
gulp.watch('./src/scripts//.js',['jshint','scripts']);
gulp.watch('./src/images//',['images']);
var server =liveReload(); //create a liveReload server
gulp.watch(['./src/**']).on('changed',function(file)
{
server.changed(file.path);
})
});