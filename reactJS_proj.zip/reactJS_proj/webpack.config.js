var config:{
entry:'./main.js',

output:{
path:'/',
filename:'index.html',},
devServer:{
inline:true,
port:8080
}