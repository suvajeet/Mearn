import React from 'react';

class TemperatureInput extends React.Component {
render()
{
  var i=1;
  var myStyle={fontsize:30,color: '#FF0000'};
return (  
<div>
<h1 style={myStyle}>Welcome to React.js</h1>
<h2>Welcome to Reacj.js Example</h2>
<p>This is a content</p>
The sum is <h3>{12+13}</h3>
The sub is <h3>{12-13}</h3>
The mul is <h3>{12*13}</h3>
The div is <h3>{12/13}</h3>
Ternary operator : <h3>{i==1 ? 'True':'False'}</h3>
</div>
);
}
}

export default TemperatureInput;
