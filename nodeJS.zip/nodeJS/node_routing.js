var express=require('express');
var bodyParser=require('body-parser');
var app=express();

app.use(bodyParser());
app.get('/index.html',function(req,res)
{
res.sendFile(__dirname+"/"+"index.html");
});
app.get('/saveUsers',function(req,res)
{
response={firstname:req.query.firstname,lastname:req.query.lastname,address:req.query.address,emial:req.query.email};
console.log(response);
res.end(JSON.stringify(response));
});

app.listen(9000,function()
{
console.log("server running at port no 9000");
});
