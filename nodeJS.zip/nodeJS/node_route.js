var express=require('express');
var bodyParser=require('body-parser');
var app=express();

app.use(bodyParser());
app.get('/',function(req,res)
{
res.json({'message':'data from userend'});
});
app.get('/userdata',function(req,res)
{
res.json({'message':'data from user end user data'});
});
app.post('/saveUsers',function(req,res)
{
res.json({'message':'data from userend'});
});
app.listen(9000,function()
{
console.log("server running at port no 9000");
});
